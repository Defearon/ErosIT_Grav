<?php

namespace Grav\Framework\File\Formatter;

use Grav\Framework\File\Interfaces\FileFormatterInterface;

/**
 * @deprecated 1.6 Use Grav\Framework\File\Interfaces\FileFormatterInterface instead
 */
interface FormatterInterface extends FileFormatterInterface
{
}
